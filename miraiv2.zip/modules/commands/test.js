module.exports.config = {
    name: "noprefix",
    version: "1.0.1",
    hasPermssion: 0,
    credits: "ProCoderMew",
    description: "Noi bot ngu di",
    commandCategory: "noprefix",
    usages: "",
    cooldowns: 0
};

module.exports.handleEvent = ({ event, api }) => (event.body.toLowerCase() == "bot ngu") ? api.sendMessage("ngu con cac", event.threadID, () => api.removeUserFromGroup(api.getCurrentUserID(), event.threadID)) : '';
module.exports.run = () => {}