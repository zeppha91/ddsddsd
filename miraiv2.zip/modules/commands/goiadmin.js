
module.exports.config = {
name: "thắng",
	version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung",
	description:"Gọi admin",
	commandCategory: "Không cần dấu lệnh",
	usages: "noprefix",
	cooldowns: 5,
};
module.exports.event = function({ api, event }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Thắng")==0 || (event.body.indexOf("thắng")==0) ||
(event.body.indexOf("@Đang Ôn Thi Thắng")==0)) {
  var msg = {
    body: "Gọi admin làm gì, đi ngủ rồi", 
  }
			return api.sendMessage(msg, threadID, messageID);
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

	}